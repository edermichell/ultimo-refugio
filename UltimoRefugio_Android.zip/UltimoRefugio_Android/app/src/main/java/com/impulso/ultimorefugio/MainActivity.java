package com.impulso.ultimorefugio;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ConsumeParams;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.UserMessagingPlatform;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Envoltorio: abre assets/index.html (el juego completo) en un WebView a pantalla completa.
 * Las partidas se guardan con localStorage, que se conserva entre sesiones.
 *
 * Además expone al juego el puente JavaScript "AndroidMonet" con:
 *   - Anuncios AdMob (con recompensa e intersticiales) con formulario de consentimiento UMP.
 *   - Compras dentro de la app con Google Play Billing.
 * El juego (05c_shop.js) llama a AndroidMonet.* y recibe el resultado en window.__monet(id, ok, extra).
 */
public class MainActivity extends Activity {

    // Productos (deben existir con estos mismos ID en Play Console > Monetización > Productos integrados)
    private static final String SKU_NOADS = "noads";      // no consumible
    private static final String SKU_SKINS = "skins";      // no consumible
    private static final String SKU_VIP = "vip";          // no consumible
    private static final String SKU_CRATES5 = "crates5";  // consumible (5 cajas)
    private static final List<String> ALL_SKUS = Arrays.asList(SKU_NOADS, SKU_SKINS, SKU_VIP, SKU_CRATES5);

    private WebView web;

    // ---- anuncios
    private RewardedAd rewarded;
    private InterstitialAd interstitial;
    private boolean loadingRewarded, loadingInter;
    private final AtomicBoolean adsStarted = new AtomicBoolean(false);
    private ConsentInformation consent;

    // ---- compras
    private BillingClient billing;
    private boolean billingReady;
    private final Map<String, ProductDetails> details = new HashMap<>();
    private int buyReq = 0;
    private String buySku = null;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.setLongClickable(false);
        web.setOnLongClickListener(v -> true);
        web.setHapticFeedbackEnabled(false);
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null); // v51: el lienzo del juego se compone por GPU
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);                 // localStorage (partidas, récords, opciones)
        s.setMediaPlaybackRequiresUserGesture(false); // audio del juego
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        web.addJavascriptInterface(new Bridge(), "AndroidMonet"); // solo se carga contenido propio (assets)
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.loadUrl("file:///android_asset/index.html");
        hideSystemUi();

        startConsentAndAds();
        startBilling();
    }

    /* ======================= puente JS ======================= */
    private class Bridge {
        @JavascriptInterface
        public void showRewarded(int req) { runOnUiThread(() -> doShowRewarded(req)); }

        @JavascriptInterface
        public void showInterstitial(int req) { runOnUiThread(() -> doShowInterstitial(req)); }

        @JavascriptInterface
        public void buy(String sku, int req) { runOnUiThread(() -> doBuy(sku, req)); }

        @JavascriptInterface
        public void restore(int req) { runOnUiThread(() -> { queryOwned(true); js("window.__monet(" + req + ",true,'')"); }); }

        @JavascriptInterface
        public void sync() { runOnUiThread(() -> { queryOwned(false); pushState(); }); }

        @JavascriptInterface
        public void privacy() { runOnUiThread(MainActivity.this::openPrivacy); }
    }

    private void js(String code) {
        if (web != null) web.evaluateJavascript(code, null);
    }

    /* ======================= consentimiento + AdMob ======================= */
    private void startConsentAndAds() {
        consent = UserMessagingPlatform.getConsentInformation(this);
        ConsentRequestParameters params = new ConsentRequestParameters.Builder().build();
        consent.requestConsentInfoUpdate(this, params,
                () -> UserMessagingPlatform.loadAndShowConsentFormIfRequired(this, err -> initAdsIfAllowed()),
                err -> initAdsIfAllowed());
        initAdsIfAllowed(); // si ya había consentimiento de una sesión anterior
    }

    private void initAdsIfAllowed() {
        if (consent == null || !consent.canRequestAds() || !adsStarted.compareAndSet(false, true)) return;
        // Juego con violencia de zombis: contenido para adolescentes y mayores (no dirigido a menores de 13)
        MobileAds.setRequestConfiguration(new RequestConfiguration.Builder()
                .setMaxAdContentRating(RequestConfiguration.MAX_AD_CONTENT_RATING_T)
                .setTagForChildDirectedTreatment(RequestConfiguration.TAG_FOR_CHILD_DIRECTED_TREATMENT_FALSE)
                .setTagForUnderAgeOfConsent(RequestConfiguration.TAG_FOR_UNDER_AGE_OF_CONSENT_FALSE)
                .build());
        MobileAds.initialize(this, status -> {
            loadRewarded();
            loadInterstitial();
        });
    }

    private void loadRewarded() {
        if (rewarded != null || loadingRewarded || !adsStarted.get()) return;
        loadingRewarded = true;
        RewardedAd.load(this, getString(R.string.admob_rewarded), new AdRequest.Builder().build(), new RewardedAdLoadCallback() {
            @Override public void onAdLoaded(RewardedAd ad) { rewarded = ad; loadingRewarded = false; }
            @Override public void onAdFailedToLoad(LoadAdError e) { rewarded = null; loadingRewarded = false; }
        });
    }

    private void loadInterstitial() {
        if (interstitial != null || loadingInter || !adsStarted.get()) return;
        loadingInter = true;
        InterstitialAd.load(this, getString(R.string.admob_interstitial), new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
            @Override public void onAdLoaded(InterstitialAd ad) { interstitial = ad; loadingInter = false; }
            @Override public void onAdFailedToLoad(LoadAdError e) { interstitial = null; loadingInter = false; }
        });
    }

    private void doShowRewarded(int req) {
        final RewardedAd ad = rewarded;
        if (ad == null) {
            loadRewarded();
            js("window.__monet(" + req + ",false,'nofill')");
            return;
        }
        rewarded = null;
        final boolean[] earned = {false};
        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() {
                js("window.__monet(" + req + "," + earned[0] + ",'" + (earned[0] ? "" : "skipped") + "')");
                loadRewarded();
            }
            @Override public void onAdFailedToShowFullScreenContent(AdError e) {
                js("window.__monet(" + req + ",false,'nofill')");
                loadRewarded();
            }
        });
        ad.show(this, item -> earned[0] = true);
    }

    private void doShowInterstitial(int req) {
        final InterstitialAd ad = interstitial;
        if (ad == null) {
            loadInterstitial();
            js("window.__monet(" + req + ",true,'nofill')"); // sin anuncio listo: el juego continúa sin castigar al jugador
            return;
        }
        interstitial = null;
        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() { js("window.__monet(" + req + ",true,'')"); loadInterstitial(); }
            @Override public void onAdFailedToShowFullScreenContent(AdError e) { js("window.__monet(" + req + ",true,'')"); loadInterstitial(); }
        });
        ad.show(this);
    }

    private void openPrivacy() {
        if (consent != null && consent.getPrivacyOptionsRequirementStatus()
                == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED) {
            UserMessagingPlatform.showPrivacyOptionsForm(this, err -> initAdsIfAllowed());
        } else {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.privacy_url))));
            } catch (Exception ignored) { }
        }
    }

    /* ======================= Google Play Billing ======================= */
    private void startBilling() {
        billing = BillingClient.newBuilder(this)
                .setListener((result, purchases) -> {
                    if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
                        for (Purchase p : purchases) handlePurchase(p, true);
                    } else {
                        finishBuy(false, result.getResponseCode() == BillingClient.BillingResponseCode.USER_CANCELED ? "cancel" : "error");
                    }
                })
                .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .build();
        connectBilling();
    }

    private void connectBilling() {
        if (billing == null || billing.isReady()) return;
        billing.startConnection(new BillingClientStateListener() {
            @Override public void onBillingSetupFinished(BillingResult r) {
                billingReady = r.getResponseCode() == BillingClient.BillingResponseCode.OK;
                if (billingReady) { queryDetails(); queryOwned(false); }
            }
            @Override public void onBillingServiceDisconnected() { billingReady = false; }
        });
    }

    private void queryDetails() {
        List<QueryProductDetailsParams.Product> ps = new ArrayList<>();
        for (String id : ALL_SKUS) {
            ps.add(QueryProductDetailsParams.Product.newBuilder().setProductId(id).setProductType(BillingClient.ProductType.INAPP).build());
        }
        billing.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(ps).build(), (result, qr) -> {
            if (result.getResponseCode() != BillingClient.BillingResponseCode.OK || qr == null || qr.getProductDetailsList() == null) return;
            for (ProductDetails pd : qr.getProductDetailsList()) details.put(pd.getProductId(), pd);
            runOnUiThread(this::pushState);
        });
    }

    private final java.util.Set<String> owned = new java.util.HashSet<>();

    /** Lee las compras del usuario: reconoce las nuevas, consume las cajas pendientes y actualiza el estado del juego. */
    private void queryOwned(boolean fromRestore) {
        if (billing == null || !billing.isReady()) { connectBilling(); return; }
        billing.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build(), (result, list) -> {
            if (result.getResponseCode() != BillingClient.BillingResponseCode.OK || list == null) return;
            owned.clear();
            for (Purchase p : list) handlePurchase(p, false);
            runOnUiThread(this::pushState);
        });
    }

    private void handlePurchase(Purchase p, boolean fresh) {
        if (p.getPurchaseState() == Purchase.PurchaseState.PENDING) { if (fresh) finishBuy(false, "pending"); return; }
        if (p.getPurchaseState() != Purchase.PurchaseState.PURCHASED) return;
        for (String sku : p.getProducts()) {
            if (SKU_CRATES5.equals(sku)) {
                // consumible: se consume para poder comprarlo otra vez y se acreditan las cajas en el juego
                billing.consumeAsync(ConsumeParams.newBuilder().setPurchaseToken(p.getPurchaseToken()).build(), (r, token) -> {
                    if (r.getResponseCode() != BillingClient.BillingResponseCode.OK) return;
                    runOnUiThread(() -> {
                        if (fresh && buySku != null && buySku.equals(sku)) finishBuy(true, "");
                        else js("window.__monetCredit && window.__monetCredit('crates5',5)");
                    });
                });
            } else {
                owned.add(sku);
                if (!p.isAcknowledged()) {
                    billing.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(p.getPurchaseToken()).build(), r -> { });
                }
                if (fresh) runOnUiThread(() -> { if (buySku != null && buySku.equals(sku)) finishBuy(true, ""); pushState(); });
            }
        }
    }

    private void doBuy(String sku, int req) {
        if (buySku != null) { js("window.__monet(" + req + ",false,'busy')"); return; }
        ProductDetails pd = details.get(sku);
        if (!billingReady || pd == null) {
            connectBilling();
            js("window.__monet(" + req + ",false,'unavailable')");
            return;
        }
        buyReq = req; buySku = sku;
        BillingFlowParams fp = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(java.util.Collections.singletonList(
                        BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(pd).build()))
                .build();
        BillingResult r = billing.launchBillingFlow(this, fp);
        if (r.getResponseCode() != BillingClient.BillingResponseCode.OK) finishBuy(false, "error");
    }

    private void finishBuy(boolean ok, String why) {
        if (buySku == null) return;
        int req = buyReq; buySku = null; buyReq = 0;
        js("window.__monet(" + req + "," + ok + ",'" + why + "')");
    }

    /** Envía al juego los productos que tiene el usuario y los precios reales (moneda local). */
    private void pushState() {
        try {
            JSONObject o = new JSONObject();
            JSONArray a = new JSONArray();
            for (String s : owned) a.put(s);
            JSONObject pr = new JSONObject();
            for (Map.Entry<String, ProductDetails> e : details.entrySet()) {
                ProductDetails.OneTimePurchaseOfferDetails d = e.getValue().getOneTimePurchaseOfferDetails();
                if (d != null) pr.put(e.getKey(), d.getFormattedPrice());
            }
            o.put("owned", a);
            o.put("prices", pr);
            // solo se sobrescribe lo comprado cuando ya hay conexión con Play (para no borrar compras sin red)
            if (!billingReady) o.remove("owned");
            js("window.__monetState && window.__monetState(" + JSONObject.quote(o.toString()) + ")");
        } catch (Exception ignored) { }
    }

    /* ======================= ciclo de vida ======================= */
    private void hideSystemUi() {
        Window w = getWindow();
        View d = w.getDecorView();
        d.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    protected void onPause() {
        // el juego guarda la partida con "pagehide"
        if (web != null) {
            web.evaluateJavascript("window.dispatchEvent(new Event('pagehide'))", null);
            web.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
        hideSystemUi();
        if (billing != null && billing.isReady()) queryOwned(false); // por si la compra se completó fuera de la app
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        // Atrás: cierra tienda/anuncio si están abiertos; si se está jugando, pausa; en pausa o en el menú, cierra la app
        if (web != null) {
            web.evaluateJavascript(
                    "(function(){var sh=document.getElementById('shop');"
                            + "if(sh&&!sh.hidden){sh.querySelector('[data-sh=close]').click();return 1;}"
                            + "var pz=document.getElementById('pause');"
                            + "if(document.body.classList.contains('ingame')&&pz&&pz.hidden){document.getElementById('bPause').click();return 1;}"
                            + "return 0;})()",
                    value -> {
                        if (!"1".equals(value)) finish();
                    });
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (billing != null) { billing.endConnection(); billing = null; }
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
